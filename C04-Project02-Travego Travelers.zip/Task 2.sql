select * from passenger;

SELECT COUNT(*) AS Female_Passengers_Count
FROM Passenger
WHERE Gender = 'F' AND Distance >= 600;


select passenger_id,passenger_name,Distance,Bus_type from passenger
where distance>500 and bus_type='Sleeper';

select * from passenger where passenger_name like 's%';

SELECT p.Passenger_name, p.Boarding_City, p.Destination_City, p.Bus_Type, pr.Price
FROM Passenger p
JOIN Price pr ON p.Bus_Type = pr.Bus_Type AND p.Distance = pr.Distance;

SELECT p.Passenger_name, pr.Price
FROM Passenger P
JOIN Price pr ON p.Bus_Type = pr.Bus_Type AND p.Distance = pr.Distance
WHERE p.Distance = 1000 AND p.Bus_Type = 'Sitting';

SELECT p.Passenger_name, pr_sitting.Price AS SittingCharge, pr_sleeper.Price AS SleeperCharge
FROM Passenger p
JOIN Price pr_sitting ON p.Distance = pr_sitting.Distance AND pr_sitting.Bus_Type = 'Sitting'
JOIN Price pr_sleeper ON p.Distance = pr_sleeper.Distance AND pr_sleeper.Bus_Type = 'Sleeper'
WHERE p.Passenger_name = 'Pallavi' AND p.Boarding_City = 'Bangaluru' AND p.Destination_City = 'Panaji';

UPDATE Passenger
SET Category = 'Non-AC'
WHERE Bus_Type = 'Sleeper';
 
SELECT * FROM passenger;
 
DELETE FROM Passenger
WHERE Passenger_name = 'Piyush';
COMMIT;

truncate table passenger;

drop table passenger;


















